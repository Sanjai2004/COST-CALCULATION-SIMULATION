document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("calculation-form");
    const resultElement = document.getElementById("calculation-result");
    const fcElement = document.getElementById("calculation-fc");
    const vcElement = document.getElementById("calculation-vc");
    const tcElement = document.getElementById("calculation-tc");
    const machineSelect = document.getElementById("machine-number"); // Change variable name to match the HTML element

    let efficiency = 0;
    let setupTimeHours = 0;
    let machineTimeSeconds = 0;

    // Function to perform the calculation
    function calculate() {
        // Check if all required inputs are available
        if (efficiency && setupTimeHours && machineTimeSeconds) {
            const selectedMachine = machineSelect.value.split(" - ")[0];

            // Fetch FC, VC, and TC for the selected machine
            fetch(`get-machine-data.php?selectedMachine=${selectedMachine}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    const machine = data.find(machine => machine['Work Centre'] === selectedMachine);
                    if (machine) {
                        const machineFC = parseFloat(machine.FC.replace(/,/g, ''));
                        const machineVC = parseFloat(machine.VC.replace(/,/g, ''));
                        const ncInput = form.elements["Net-Contribution"].value;
                        // Calculate Result
                        const cycleTimeHours = machineTimeSeconds / 3600;
                        const result = setupTimeHours + cycleTimeHours + ((setupTimeHours + cycleTimeHours) * (100 % - efficiency));

                        const FC = result * machineFC;
                        const VC = result * machineVC;
                        const TC = FC + VC;
                        const NC = parseFloat(ncInput);

                        // Calculate Selling Price (SP)
                        const SP = TC / (1 - NC / 100);

                        // Calculate Gross Contribution (GC) and GC Percentage
                        const GC = SP - VC;
                        const GCPercentage = (GC / SP) * 100;

                        // Debugging output
                        console.log("Input Values:");
                        console.log("Efficiency: " + efficiency);
                        console.log("Setup Time (Hours): " + setupTimeHours);
                        console.log("Machine Time (Seconds): " + machineTimeSeconds);
                        console.log("NC Input: " + NC);
                        console.log("Intermediate Calculations:");
                        console.log("Cycle Time (Hours): " + cycleTimeHours);
                        console.log("Result: " + result);
                        console.log("FC: " + FC);
                        console.log("VC: " + VC);
                        console.log("TC: " + TC);
                        console.log("SP: " + SP);
                        console.log("GC: " + GC);
                        console.log("GC Percentage: " + GCPercentage);


                        // Display results
                        resultElement.textContent = `Result: ${result.toFixed(2)} hrs`;
                        fcElement.textContent = `FC: ${FC.toFixed(2)}`;
                        vcElement.textContent = `VC: ${VC.toFixed(2)}`;
                        tcElement.textContent = `TC: ${TC.toFixed(2)}`;
                        document.getElementById("calculation-sp").textContent = `SP: ${SP.toFixed(2)}`;
                        document.getElementById("calculation-gc").textContent = `GC: ${GC.toFixed(2)}`;
                        document.getElementById("calculation-gcp").textContent = `GC (%): ${GCPercentage.toFixed(2)}%`;
                    } else {
                        resultElement.textContent = "Invalid machine selection.";
                        fcElement.textContent = "FC: N/A";
                        vcElement.textContent = "VC: N/A";
                        tcElement.textContent = "TC: N/A";
                        document.getElementById("calculation-sp").textContent = "SP: N/A";
                        document.getElementById("calculation-gc").textContent = "GC: N/A";
                        document.getElementById("calculation-gcp").textContent = "GC (%): N/A";
                    }
                })
                .catch(error => {
                    console.error("Error fetching machine details: " + error);
                    return {}; // Return empty object in case of an error
                });
        } else {
            // If any required input is missing, display a message
            resultElement.textContent = "Please provide all inputs.";
            fcElement.textContent = "FC: N/A";
            vcElement.textContent = "VC: N/A";
            tcElement.textContent = "TC: N/A";
            document.getElementById("calculation-sp").textContent = "SP: N/A";
            document.getElementById("calculation-gc").textContent = "GC: N/A";
            document.getElementById("calculation-gcp").textContent = "GC (%): N/A";
        }
    }

    // Add an event listener to the machineSelect dropdown to trigger the calculation
    machineSelect.addEventListener("change", calculate);

    // Add event listeners to input fields to update values
    form.elements["efficiency"].addEventListener("input", function () {
        efficiency = parseFloat(form.elements["efficiency"].value);
        calculate();
    });

    form.elements["setup-time"].addEventListener("input", function () {
        setupTimeHours = parseFloat(form.elements["setup-time"].value);
        calculate();
    });

    form.elements["machine-time-seconds"].addEventListener("input", function () {
        machineTimeSeconds = parseFloat(form.elements["machine-time-seconds"].value);
        calculate();
    });

    // Fetch data from the server and populate the dropdown
    fetch("get-machine-data.php")
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Loop through the data and populate the dropdown
            data.forEach(machine => {
                const option = document.createElement("option");
                // Combine Work Center and Machine and use it as both value and text
                const workCenterMachine = `${machine['Work Centre']} - ${machine['Machine']}`;
                option.value = workCenterMachine; // Set the value
                option.textContent = workCenterMachine; // Set the display text
                machineSelect.appendChild(option); // Append the option to the select element
            });
        })
        .catch(error => console.error("Error fetching data: " + error));
});
