<?php
// Replace with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cost_calculator";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve machine data
$sql = "SELECT * FROM `machinedata`";
$result = $conn->query($sql);

// Check if there are rows in the result
if ($result->num_rows > 0) {
    $machineData = array();
    
    // Fetch data and store it in an array
    while ($row = $result->fetch_assoc()) {
        $machineData[] = $row;
    }
    
    // Close the database connection
    $conn->close();
    

    // Send the data as JSON
    header('Content-Type: application/json');
    echo json_encode($machineData);
} else {
    echo "No data found";
}
?>
