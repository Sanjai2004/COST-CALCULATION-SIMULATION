<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cost_calculator";

// Create a database connection
$connection = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection is successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve data from the form
$workCentre = $_POST['work-centre'];
$machine = $_POST['machine'];
$fc = $_POST['fc'];
$vc = $_POST['vc'];
$tc = $_POST['tc'];

// Check if the data already exists
$query = "SELECT * FROM `machinedata` WHERE `Work Centre` = '$workCentre' AND `Machine` = '$machine'";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    // Data already exists, add a message to the response
    $response["success"] = false;
    $response["message"] = "Data already exists!";
} else {
    // Data doesn't exist, insert it into the database
    $insertQuery = "INSERT INTO `machinedata` (`Work Centre`, `Machine`, `FC`, `VC`, `TC`) VALUES ('$workCentre', '$machine', '$fc', '$vc', '$tc')";
    
    if (mysqli_query($connection, $insertQuery)) {
        $response["success"] = true;
        $response["message"] = "Data added successfully!";
    } else {
        $response["success"] = false;
        $response["message"] = "Error adding data.";
    }
}

// Close the database connection
mysqli_close($connection);

// Return the response as JSON
echo json_encode($response);
?>