<?php
// Assuming you have a database connection established
// Replace with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cost_calculator";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $workCentre = $_POST['deleteWorkCentre'];
    $machine = $_POST['deleteMachine'];

    // Perform a database delete query to delete machine data based on Work Centre and Machine
    // Replace this with your actual database delete query
    $query = "DELETE FROM machinedata WHERE `Work Centre` = '$workCentre' AND `Machine` = '$machine'";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Database delete failed"]);
    }
    $conn->close();
    
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
?>
